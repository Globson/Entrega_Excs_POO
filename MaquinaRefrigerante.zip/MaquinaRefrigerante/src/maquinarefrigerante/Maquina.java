/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package maquinarefrigerante;
import java.util.ArrayList;
/**
 *
 * @author Aluno
 */
public class Maquina {
    private double Saldo;
    private ArrayList<Refrigerante> Refris;
    private int Quantidade[];
    private int indiceRefris;
    private double Credito;
    
    public Maquina(){
        Saldo = 10;
        Credito = 0;
        Refris = new ArrayList<Refrigerante>();
        Quantidade = new int[5];
        for(int i=0;i<5;i++){
            Quantidade[i] = 0;
        }
    }
    
    public boolean RecebeCredito(double credito){
        if(credito>0){
            Credito = Credito + credito;
            return true;
        }
        return false;
    }
    
    public boolean CancelaVenda(){
        MoedasTroco(-1);
        return true;
    }
    
    public void ExibeCredito(){
        System.out.println("Credito inserido: "+Credito);
    }
    
    public void EscolheRefri(int Index){
        Index = Index - 1;
        indiceRefris = Index;
    }
    
    public boolean AlteraQuantidade(int index,int quant){
        if(index<5 && index>=0 && quant>0){
            Quantidade[index] = quant;
            return true;
        }
        return false;
    }
    
    public double Troco(double precoRefri){
        if(precoRefri == -1){
            return Credito;
        }
        else{
            double troco = Credito - precoRefri;
            Credito = 0;
            Saldo += precoRefri;
            //System.out.println("Saldo: "+Saldo);  
            return troco;
        }
    }
    
    public void MoedasTroco(double precoRefri){
        double troco = Troco(precoRefri);
        System.out.println("Seu troco é "+troco);
    }
    
    public void SetRefri(String nome,double preco,int index){
        Refrigerante Refri = new Refrigerante();
        Refri.SetNome(nome);
        Refri.SetPreco(preco);
        Refris.add(index, Refri);
    }
    public void GetRefris(){
        for(int i =0;i<5;i++){
            System.out.println("Refrigerante  "+(i+1)+ " - "+Refris.get(i).GetNome()+" Preco: "+Refris.get(i).GetPreco());
        }
    }
    
    public boolean Venda(){
        if(indiceRefris>=0 && indiceRefris<5){
            if(Credito>= Refris.get(indiceRefris).GetPreco() &&Quantidade[indiceRefris]>0){
                Quantidade[indiceRefris]--;
                System.out.println("Quantidade de refris restantes: "+Quantidade[indiceRefris]);
                MoedasTroco(Refris.get(indiceRefris).GetPreco());
                System.out.println("Refrigerante vendido!");
                return true;
            }
            else{
                CancelaVenda();
                Credito = 0;
                System.out.println("Credito insuficiente");
                return false;
            }
        }
        else{
                CancelaVenda();
                Credito = 0;
                System.out.println("Refrigerante invalido!");
                return false;
            }
    }
}
