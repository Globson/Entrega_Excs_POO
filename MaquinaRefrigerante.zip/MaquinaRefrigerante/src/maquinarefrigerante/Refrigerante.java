/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package maquinarefrigerante;

/**
 *
 * @author Aluno
 */
public class Refrigerante {
    private String Nome;
    private double Preco;
    
    public void SetNome(String nome){
        Nome = nome;
    }
    
    public boolean SetPreco(double preco){
        if(preco>0){
            Preco = preco;
            return true;
        }
        return false;
    }
    
    public String GetNome(){
        return Nome;
    }
    
    public double GetPreco(){
        return Preco;
    }
    
}
