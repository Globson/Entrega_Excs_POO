/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package maquinarefrigerante;
import java.util.Scanner;
/**
 *
 * @author Aluno
 */
public class MaquinaRefrigerante {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        Scanner sc = new Scanner(System.in);
        Maquina Maquina1 = new Maquina();
        Maquina1.SetRefri("Coca", 5, 0);
        Maquina1.AlteraQuantidade(0,20);
        Maquina1.SetRefri("Fanta", 4.5, 1);
        Maquina1.AlteraQuantidade(1,20);
        Maquina1.SetRefri("Sprite", 4, 2);
        Maquina1.AlteraQuantidade(2,20);
        Maquina1.SetRefri("Pepsi", 3.9, 3);
        Maquina1.AlteraQuantidade(3,20);
        Maquina1.SetRefri("Soda", 3.5, 4);
        Maquina1.AlteraQuantidade(4,20);
        while(true){
            System.out.println("\tMaquina de refrigerante");
            Maquina1.GetRefris();
            while(true){
                System.out.print("Entre com o credito: ");
                double credito = sc.nextDouble();
                Maquina1.RecebeCredito(credito);
                Maquina1.ExibeCredito();
                System.out.println("Deseja entrar com mais credito?");
                System.out.println("\t1 - Sim\n\t2 - Nao");
                System.out.print("Entre:");
                int a = sc.nextInt();
                if(a == 2){
                    break;
                }   
            }
            System.out.print("Entre com o numero do refrigerante:");
            int b = sc.nextInt();
            Maquina1.EscolheRefri(b);
            Maquina1.Venda();
        }
    }
}
